# CompanyMicroserviceSpringCloud
Architecture distribuée basée sur Micro Services avec Spring Cloud:
  - Partie Micro service métier - service-company
  - Partie Service de configuration
  - Eureka Registration Service
  - Partie Service api gateway
  
  NB: le dossier contient la confiruration globale des microservices nommé "cloud-conf" doit être placer sous le dosier utilisateur. 
