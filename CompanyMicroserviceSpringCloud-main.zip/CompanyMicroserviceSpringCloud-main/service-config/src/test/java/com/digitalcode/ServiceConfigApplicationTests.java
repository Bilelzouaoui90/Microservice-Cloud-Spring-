package com.digitalcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
